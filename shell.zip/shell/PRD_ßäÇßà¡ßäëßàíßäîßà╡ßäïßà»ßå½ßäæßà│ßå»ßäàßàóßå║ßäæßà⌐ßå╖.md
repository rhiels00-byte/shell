# 📚 교사 지원 플랫폼 PRD (Product Requirements Document)

**문서 버전:** v1.0  
**작성일:** 2026년 1월 30일  
**상태:** 초안

---

## 1. 개요 (Executive Summary)

### 1.1 제품 비전
AI를 활용하여 교사가 원하는 산출물을 빠르고 정확하게 제공하는 **"교사 지원툴"** 플랫폼을 개발합니다. 교사가 "이거 진짜 좋다", "이거 계속 쓰고 싶다"라고 느낄 수 있는 서비스를 목표로 합니다.

### 1.2 핵심 가치
- **효율성:** AI 기반으로 교사의 업무 시간 단축
- **확장성:** 다양한 도구(Tool)를 지속적으로 추가 가능한 플랫폼 구조
- **사용성:** 직관적인 UI/UX로 누구나 쉽게 사용

### 1.3 타겟 사용자
- 초등/중등/고등학교 교사
- 다중 학급 및 과목을 담당하는 교사

---

## 2. 기능 명세 (Feature Specifications)

### 2.1 인증 시스템 (Authentication)

#### 2.1.1 회원가입
| 필드명 | 타입 | 필수 | 설명 |
|--------|------|------|------|
| ID | string | ✅ | 사용자 고유 아이디 |
| Password | string | ✅ | 비밀번호 (암호화 저장) |
| 학급 정보 | array | ✅ | 담당 학급 (복수 선택 가능) |
| 과목 정보 | array | ✅ | 담당 과목 (복수 선택 가능) |

**데이터 구조 예시:**
```json
{
  "userId": "teacher001",
  "password": "hashed_password",
  "classes": [
    { "grade": 2, "class": 3 },
    { "grade": 2, "class": 5 }
  ],
  "subjects": ["수학", "과학"]
}
```

#### 2.1.2 로그인
- 아이디/비밀번호 입력
- **아이디 저장** 체크박스
- **비밀번호 저장** 체크박스
- 자동 로그인 옵션

---

### 2.2 홈 화면 (Home)

#### 2.2.1 메인 프롬프트 입력창
- GPT 스타일의 대화형 입력 인터페이스
- 플레이스홀더: "무엇을 도와드릴까요?"
- 음성 입력 버튼 (선택사항)
- 파일 첨부 버튼

#### 2.2.2 도구 타일 그리드
- 메인 기능 하단에 타일 형태로 도구 목록 표시
- 각 타일 구성요소:
  - 아이콘
  - 도구명
  - 간략 설명
  - 분류 태그 (생성/분석)

**타일 레이아웃:**
```
┌─────────┐ ┌─────────┐ ┌─────────┐
│  아이콘  │ │  아이콘  │ │  아이콘  │
│ 도구명   │ │ 도구명   │ │ 도구명   │
│ [생성]   │ │ [분석]   │ │ [생성]   │
└─────────┘ └─────────┘ └─────────┘
```

---

### 2.3 LNB (Left Navigation Bar)

#### 2.3.1 메뉴 구조
```
📍 홈
📦 도구
   ├── 전체
   ├── 생성
   └── 분석
💬 채팅 내역
📁 만든 자료
⚙️ 설정
```

#### 2.3.2 도구 페이지
- 타일 형태로 모든 도구 표시
- 분류별 필터링 (전체/생성/분석)
- 검색 기능
- 즐겨찾기 기능

---

### 2.4 채팅 내역 (Chat History)

#### 2.4.1 기능 요구사항
- 도구 사용 시 발생하는 모든 대화 저장
- 시간순 정렬 (최신순/오래된순)
- 도구별 필터링
- 검색 기능
- 대화 삭제 기능

#### 2.4.2 채팅 기록 데이터 구조
```json
{
  "chatId": "chat_001",
  "toolId": "tool_quiz_generator",
  "toolName": "퀴즈 생성기",
  "createdAt": "2026-01-30T10:30:00Z",
  "messages": [
    {
      "role": "user",
      "content": "수학 2단원 퀴즈 만들어줘",
      "timestamp": "2026-01-30T10:30:00Z"
    },
    {
      "role": "assistant",
      "content": "...",
      "timestamp": "2026-01-30T10:30:05Z"
    }
  ],
  "outputId": "output_001"
}
```

---

### 2.5 만든 자료 (Created Materials)

#### 2.5.1 산출물 관리
- 도구에서 생성된 모든 산출물 저장 및 조회
- **읽기 전용** (수정 불가)
- 수정이 필요한 경우 원본 도구로 이동하여 재생성

#### 2.5.2 산출물 타입 분류

| 타입 | 형태 | 예시 | 액션 |
|------|------|------|------|
| 다운로드형 | 파일 | 엑셀, 이미지, PDF, QR코드 | 다운로드 버튼 |
| 복사형 | 텍스트 | 텍스트, 링크, 코드 | 복사 버튼 |

#### 2.5.3 산출물 데이터 구조
```json
{
  "outputId": "output_001",
  "toolId": "tool_quiz_generator",
  "toolName": "퀴즈 생성기",
  "title": "수학 2단원 퀴즈",
  "type": "download",
  "format": "xlsx",
  "fileUrl": "/outputs/quiz_001.xlsx",
  "createdAt": "2026-01-30T10:30:05Z",
  "chatId": "chat_001",
  "metadata": {
    "subject": "수학",
    "grade": 2,
    "unit": 2
  }
}
```

---

### 2.6 설정 (Settings)

#### 2.6.1 설정 항목
- **계정 정보:** 프로필, 비밀번호 변경
- **학급/과목 관리:** 담당 정보 수정
- **알림 설정:** 푸시 알림 on/off
- **테마:** 라이트/다크 모드
- **언어:** 한국어 (기본)

---

## 3. 도구(Tool) 시스템

### 3.1 도구 분류 체계

| 분류 | 코드 | 설명 | 색상 |
|------|------|------|------|
| 생성 | `create` | 새로운 자료 생성 | #2196F3 (파랑) |
| 분석 | `analyze` | 기존 자료 분석 | #4CAF50 (녹색) |
| (확장) | `tbd` | 향후 추가 예정 | - |

### 3.2 도구 공통 인터페이스

#### 3.2.1 도구 메타데이터 구조
```typescript
interface Tool {
  id: string;
  name: string;
  description: string;
  icon: string;
  category: 'create' | 'analyze' | string;
  version: string;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}
```

#### 3.2.2 도구 실행 흐름
```
사용자 입력 → AI 처리 → 산출물 생성 → 저장
     ↓            ↓           ↓          ↓
  채팅 기록    응답 표시    미리보기    만든 자료
```

---

## 4. 디자인 시스템 (Design System)

### 4.1 컬러 팔레트

#### Primary Colors (Blue Theme)
```css
--primary-50: #E3F2FD;
--primary-100: #BBDEFB;
--primary-200: #90CAF9;
--primary-300: #64B5F6;
--primary-400: #42A5F5;
--primary-500: #2196F3;  /* 메인 컬러 */
--primary-600: #1E88E5;
--primary-700: #1976D2;
--primary-800: #1565C0;
--primary-900: #0D47A1;
```

#### Neutral Colors
```css
--gray-50: #FAFAFA;
--gray-100: #F5F5F5;
--gray-200: #EEEEEE;
--gray-300: #E0E0E0;
--gray-400: #BDBDBD;
--gray-500: #9E9E9E;
--gray-600: #757575;
--gray-700: #616161;
--gray-800: #424242;
--gray-900: #212121;
```

#### Category Colors
```css
--category-create: #2196F3;  /* 생성 */
--category-analyze: #4CAF50; /* 분석 */
```

### 4.2 타이포그래피

```css
/* Font Family */
font-family: 'Pretendard', -apple-system, BlinkMacSystemFont, sans-serif;

/* Font Sizes */
--text-xs: 12px;
--text-sm: 14px;
--text-base: 16px;
--text-lg: 18px;
--text-xl: 20px;
--text-2xl: 24px;
--text-3xl: 30px;
```

### 4.3 Border Radius (동글동글한 스타일)

```css
--radius-sm: 8px;
--radius-md: 12px;
--radius-lg: 16px;
--radius-xl: 20px;
--radius-2xl: 24px;
--radius-full: 9999px;
```

### 4.4 컴포넌트 스타일

#### 4.4.1 버튼
```css
.button-primary {
  background: var(--primary-500);
  color: white;
  border-radius: var(--radius-lg);
  padding: 12px 24px;
  font-weight: 600;
  transition: all 0.2s ease;
}

.button-primary:hover {
  background: var(--primary-600);
  transform: translateY(-1px);
  box-shadow: 0 4px 12px rgba(33, 150, 243, 0.3);
}
```

#### 4.4.2 카드/타일
```css
.card {
  background: white;
  border-radius: var(--radius-xl);
  padding: 20px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
  transition: all 0.2s ease;
}

.card:hover {
  transform: translateY(-4px);
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.12);
}
```

#### 4.4.3 입력창
```css
.input {
  border: 2px solid var(--gray-200);
  border-radius: var(--radius-lg);
  padding: 14px 18px;
  font-size: var(--text-base);
  transition: all 0.2s ease;
}

.input:focus {
  border-color: var(--primary-500);
  box-shadow: 0 0 0 4px rgba(33, 150, 243, 0.1);
}
```

---

## 5. 도구 실행 화면 레이아웃 (Tool Execution Layout)

### 5.1 화면 구성 개요

도구 타일을 클릭하면 2단 레이아웃의 도구 실행 화면이 표시됩니다.

### 5.2 레이아웃 구조

```
┌─────────────────────────────────────────────────────────────────┐
│  [도구 제목]                                    [저장 옵션 ▼]  │
├──────────────────────────┬──────────────────────────────────────┤
│                          │                                      │
│   왼쪽: 입력 영역          │   오른쪽: 미리보기 영역                │
│   (프롬프터)              │   (산출물 미리보기)                   │
│                          │                                      │
│                          │                                      │
│                          │                                      │
└──────────────────────────┴──────────────────────────────────────┘
```

### 5.3 영역별 상세 설명

#### 5.3.1 왼쪽 상단 (헤더)
- **도구 제목**: 선택한 도구의 이름 표시
- **뒤로가기 버튼**: 도구 목록으로 돌아가기
- 위치: 고정 (sticky)

#### 5.3.2 왼쪽 영역 (입력 영역)
- **프롬프터**: 사용자가 정보를 입력하는 폼
- 입력 필드는 도구별로 커스터마이징 가능
- 예시:
  - 텍스트 입력
  - 드롭다운 선택
  - 파일 업로드
  - 체크박스/라디오 버튼
- **실행 버튼**: 입력 완료 후 AI 처리 시작

#### 5.3.3 오른쪽 영역 (미리보기 영역)
- **산출물 미리보기**: AI가 생성한 결과물 실시간 표시
- 형식별 미리보기:
  - 텍스트: 마크다운/일반 텍스트
  - 표: 테이블 형식
  - 이미지: 이미지 뷰어
  - 문서: PDF/DOCX 프리뷰
- 로딩 상태 표시

#### 5.3.4 오른쪽 상단 (저장 옵션)
드롭다운 메뉴로 다음 옵션 제공:
1. **다운로드**: 파일로 다운로드 (xlsx, pdf, png 등)
2. **복사**: 클립보드에 복사 (텍스트/링크)
3. **만든 자료함에 저장**: 내부 저장소에 저장

### 5.4 반응형 동작

#### 데스크톱 (1024px 이상)
- 2단 레이아웃 유지
- 왼쪽 40%, 오른쪽 60%

#### 태블릿 (768px - 1023px)
- 2단 레이아웃 유지
- 왼쪽 50%, 오른쪽 50%

#### 모바일 (767px 이하)
- 1단 레이아웃으로 전환
- 입력 영역 → 미리보기 영역 순서로 세로 배치

### 5.5 UI 컴포넌트 명세

```typescript
interface ToolExecutionLayoutProps {
  toolId: string;
  toolName: string;
  inputComponent: React.ReactNode;  // 도구별 커스텀 입력 폼
  outputComponent: React.ReactNode; // 생성된 산출물
  onSave: (type: 'download' | 'copy' | 'archive') => void;
  isLoading?: boolean;
}
```

### 5.6 사용자 플로우

1. 사용자가 도구 타일 클릭
2. 도구 실행 화면으로 전환
3. 왼쪽 입력 영역에서 정보 입력
4. "생성" 버튼 클릭
5. 오른쪽 영역에 실시간으로 결과 표시
6. 오른쪽 상단 드롭다운에서 저장 방식 선택
   - 다운로드: 즉시 파일 다운로드
   - 복사: 클립보드에 복사 완료 알림
   - 만든 자료함에 저장: 저장 완료 후 Materials 페이지로 이동 옵션

---

## 6. 기술 스택 (Tech Stack)

### 5.1 권장 스택

| 레이어 | 기술 | 설명 |
|--------|------|------|
| Frontend | React + TypeScript | 컴포넌트 기반 UI |
| Styling | Tailwind CSS | 유틸리티 기반 스타일링 |
| State | Zustand / Redux Toolkit | 상태 관리 |
| Backend | Node.js + Express | API 서버 |
| Database | PostgreSQL + Prisma | 데이터 저장 |
| AI | OpenAI API | AI 기능 |
| Auth | JWT + bcrypt | 인증 |

### 5.2 폴더 구조
```
src/
├── components/
│   ├── common/        # 공통 컴포넌트
│   ├── layout/        # 레이아웃 컴포넌트
│   └── features/      # 기능별 컴포넌트
├── pages/
│   ├── Home.tsx
│   ├── Tools.tsx
│   ├── ChatHistory.tsx
│   ├── Materials.tsx
│   └── Settings.tsx
├── hooks/             # 커스텀 훅
├── services/          # API 서비스
├── stores/            # 상태 관리
├── types/             # TypeScript 타입
├── utils/             # 유틸리티 함수
└── styles/            # 글로벌 스타일
```

---

## 6. API 명세 (API Specification)

### 6.1 인증 API

```
POST /api/auth/signup      # 회원가입
POST /api/auth/login       # 로그인
POST /api/auth/logout      # 로그아웃
GET  /api/auth/me          # 현재 사용자 정보
```

### 6.2 도구 API

```
GET  /api/tools            # 도구 목록
GET  /api/tools/:id        # 도구 상세
POST /api/tools/:id/execute # 도구 실행
```

### 6.3 채팅 API

```
GET  /api/chats            # 채팅 목록
GET  /api/chats/:id        # 채팅 상세
DELETE /api/chats/:id      # 채팅 삭제
```

### 6.4 산출물 API

```
GET  /api/outputs          # 산출물 목록
GET  /api/outputs/:id      # 산출물 상세
GET  /api/outputs/:id/download # 산출물 다운로드
DELETE /api/outputs/:id    # 산출물 삭제
```

---

## 7. 데이터베이스 스키마

### 7.1 ERD 개요

```
Users
  └── Classes (1:N)
  └── Subjects (1:N)
  └── ChatSessions (1:N)
        └── Messages (1:N)
        └── Outputs (1:N)

Tools
  └── ToolCategories (N:1)
  └── ChatSessions (1:N)
  └── Outputs (1:N)
```

### 7.2 주요 테이블

#### Users
```sql
CREATE TABLE users (
  id UUID PRIMARY KEY,
  username VARCHAR(50) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);
```

#### Tools
```sql
CREATE TABLE tools (
  id UUID PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  description TEXT,
  icon VARCHAR(50),
  category VARCHAR(20) NOT NULL, -- 'create', 'analyze'
  is_active BOOLEAN DEFAULT true,
  version VARCHAR(20),
  created_at TIMESTAMP DEFAULT NOW()
);
```

#### Outputs
```sql
CREATE TABLE outputs (
  id UUID PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  tool_id UUID REFERENCES tools(id),
  chat_session_id UUID,
  title VARCHAR(200),
  output_type VARCHAR(20), -- 'download', 'copy'
  format VARCHAR(20),      -- 'xlsx', 'png', 'text', 'link'
  file_path VARCHAR(500),
  content TEXT,
  metadata JSONB,
  created_at TIMESTAMP DEFAULT NOW()
);
```

---

## 8. 마일스톤 (Milestones)

### Phase 1: MVP (4주)
- [ ] 인증 시스템 (로그인/회원가입)
- [ ] 기본 레이아웃 (LNB, 헤더)
- [ ] 홈 화면 (프롬프트 입력)
- [ ] 도구 페이지 (타일 UI)
- [ ] 기본 채팅 기능

### Phase 2: 핵심 기능 (4주)
- [ ] 채팅 내역 저장/조회
- [ ] 만든 자료 저장/조회
- [ ] 산출물 다운로드/복사 기능
- [ ] 설정 페이지

### Phase 3: 도구 개발 (지속)
- [ ] 생성형 도구 추가
- [ ] 분석형 도구 추가
- [ ] 도구별 커스텀 UI

### Phase 4: 고도화 (지속)
- [ ] 사용자 피드백 반영
- [ ] 성능 최적화
- [ ] 새로운 분류 카테고리 추가

---

## 9. 부록

### 9.1 용어 정의

| 용어 | 정의 |
|------|------|
| 도구(Tool) | 특정 기능을 수행하는 AI 기반 서비스 모듈 |
| 산출물(Output) | 도구를 통해 생성된 결과물 |
| LNB | Left Navigation Bar, 좌측 네비게이션 |
| 프롬프트 | AI에게 전달하는 사용자 입력 |

### 9.2 참고 자료
- 비바샘(VIVASAM) UI 레퍼런스
- Material Design 3 가이드라인
- Tailwind CSS 문서

---

**문서 끝**
